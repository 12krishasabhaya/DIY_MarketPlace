<?php
declare(strict_types=1);
?>
<footer class="footer bg-dark text-white py-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <h5 class="fw-bold mb-3"><?= e(APP_NAME) ?></h5>
        <p class="text-secondary">"Empowering students to build, share, and save. The ultimate marketplace for your academic journey."</p>
      </div>
      <div class="col-lg-2 col-md-6">
        <h6 class="fw-bold text-uppercase mb-3">Quick Links</h6>
        <ul class="list-unstyled">
          <li><a href="index.php" class="text-secondary text-decoration-none">Home</a></li>
          <li><a href="products.php" class="text-secondary text-decoration-none">Products</a></li>
          <li><a href="category.php" class="text-secondary text-decoration-none">Categories</a></li>
          <li><a href="post-item.php" class="text-secondary text-decoration-none">Sell Item</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-6">
        <h6 class="fw-bold text-uppercase mb-3">Support</h6>
        <ul class="list-unstyled">
          <li><a href="about.php" class="text-secondary text-decoration-none">About Us</a></li>
          <li><a href="contact.php" class="text-secondary text-decoration-none">Contact</a></li>
          <li><a href="faq.php" class="text-secondary text-decoration-none">FAQ</a></li>
          <li><a href="feedback.php" class="text-secondary text-decoration-none">Feedback</a></li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-6">
        <h6 class="fw-bold text-uppercase mb-3">Newsletter</h6>
        <p class="text-secondary">Subscribe to get updates on new listings and features.</p>
        <form id="newsletter-form" class="mb-2" autocomplete="off">
          <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
          <div class="input-group">
            <input type="email" class="form-control" name="email" placeholder="Email Address" required>
            <button class="btn btn-primary" type="submit">Subscribe</button>
          </div>
        </form>
        <div id="newsletter-msg" class="small"></div>
      </div>
    </div>
    <hr class="mt-4 mb-4 bg-secondary">
    <div class="text-center text-secondary small">
      &copy; 2026 <?= e(APP_NAME) ?>. All rights reserved.
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/validation.js"></script>
<script>
  // cart badge uses API to stay accurate across pages
  (async function() {
    const badge = document.getElementById('cart-count');
    if (!badge) return;
    try {
      const res = await fetch('api/cart.php?action=count', { credentials: 'same-origin' });
      if (!res.ok) return;
      const data = await res.json();
      badge.textContent = String(data.count ?? 0);
    } catch (e) {}
  })();

  // newsletter subscribe
  (function() {
    const form = document.getElementById('newsletter-form');
    const msg = document.getElementById('newsletter-msg');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (msg) { msg.className = 'small text-secondary'; msg.textContent = 'Subscribing...'; }
      const fd = new FormData(form);
      try {
        const res = await fetch('api/newsletter.php', { method: 'POST', body: fd, credentials: 'same-origin' });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (msg) { msg.className = 'small text-danger'; msg.textContent = data.message || 'Unable to subscribe. Please try again.'; }
          return;
        }
        if (msg) {
          msg.className = 'small text-success';
          msg.textContent = data.status === 'already_subscribed'
            ? 'You are already subscribed.'
            : 'Subscribed successfully. Thank you!';
        }
        form.reset();
      } catch (err) {
        if (msg) { msg.className = 'small text-danger'; msg.textContent = 'Network error. Please try again.'; }
      }
    });
  })();
</script>
</body>
</html>

