<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/auth.php';
$user = $user ?? auth_user();
$current = basename($_SERVER['PHP_SELF'] ?? '');
function nav_active(string $file, string $current): string {
    return $file === $current ? ' active' : '';
}
?>
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top">
  <div class="container">
    <a class="navbar-brand" href="index.php">
      <i class="fas fa-graduation-cap me-2"></i><?= e(APP_NAME) ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item"><a class="nav-link<?= nav_active('index.php', $current) ?>" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link<?= nav_active('products.php', $current) ?>" href="products.php">Product</a></li>
        <li class="nav-item"><a class="nav-link<?= nav_active('category.php', $current) ?>" href="category.php">Category</a></li>
        <li class="nav-item"><a class="nav-link<?= nav_active('about.php', $current) ?>" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link<?= nav_active('contact.php', $current) ?>" href="contact.php">Contact</a></li>

        <?php if ($user): ?>
          <?php if (($user['role'] ?? '') === 'admin'): ?>
            <li class="nav-item"><a class="nav-link<?= nav_active('admin.php', $current) ?>" href="admin.php">Admin</a></li>
          <?php else: ?>
            <li class="nav-item"><a class="nav-link<?= nav_active('dashboard.php', $current) ?>" href="dashboard.php">Dashboard</a></li>
          <?php endif; ?>
          <li class="nav-item ms-lg-3">
            <a class="nav-link btn btn-outline-primary btn-sm px-3" href="logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link btn btn-outline-primary ms-lg-3 px-4" href="login.php">Login</a></li>
        <?php endif; ?>
        <li class="nav-item ms-lg-3">
          <a class="nav-link position-relative" href="cart.php">
            <i class="fas fa-shopping-cart fs-5"></i>
            <span class="badge rounded-pill bg-danger cart-badge" id="cart-count">0</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

