<?php
declare(strict_types=1);

require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/csrf.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/store.php';

$user = auth_require_login();
$pageTitle = 'Cart - Campus Market';

if (is_post()) {
    csrf_verify();
    $action = (string)($_POST['action'] ?? '');
    $listingId = isset($_POST['listing_id']) ? (int)$_POST['listing_id'] : 0;

    if ($action === 'add' && $listingId > 0) {
        cart_add_item((int)$user['id'], $listingId, 1);
        redirect('checkout.php');
    }

    if ($action === 'remove' && $listingId > 0) {
        cart_set_quantity((int)$user['id'], $listingId, 0);
        redirect('cart.php');
    }
}

require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/partials/navbar.php';

$cart = cart_get((int)$user['id']);
$items = $cart['items'];
$total = (float)$cart['total'];
$ok = flash_get('success');
?>

<div class="container py-5">
  <div class="d-flex justify-content-between align-items-end mb-4">
    <div>
      <h2 class="fw-bold mb-0">Your Cart</h2>
      <p class="text-muted mb-0"><?= count($items) ?> item(s)</p>
    </div>
    <a href="products.php" class="btn btn-outline-secondary">Continue Shopping</a>
  </div>

  <?php if (count($items) === 0): ?>
    <div class="card border-0 shadow-sm p-5 text-center">
      <p class="text-muted mb-3">Your cart is empty.</p>
      <a href="products.php" class="btn btn-primary">Browse Products</a>
    </div>
  <?php else: ?>
    <div class="row g-4">
      <div class="col-lg-8">
        <?php foreach ($items as $it): ?>
          <div class="card border-0 shadow-sm mb-3">
            <div class="card-body d-flex gap-3 align-items-center">
              <img src="<?= e($it['image_path'] ?: 'img/placeholder.png') ?>" alt="<?= e($it['title']) ?>" style="width:90px;height:90px;object-fit:cover;border-radius:10px;">
              <div class="flex-grow-1">
                <div class="d-flex justify-content-between">
                  <div>
                    <h6 class="fw-bold mb-1"><?= e($it['title']) ?></h6>
                    <div class="small text-muted"><?= e($it['category_name']) ?> · <?= e($it['item_condition']) ?></div>
                  </div>
                  <div class="text-end">
                    <div class="fw-bold text-primary">₹<?= number_format((float)$it['price'], 0) ?></div>
                    <div class="small text-muted">Subtotal: ₹<?= number_format((float)$it['price'], 0) ?></div>
                  </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mt-3">
                  <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="listing_id" value="<?= (int)$it['listing_id'] ?>">
                    <button class="btn btn-sm btn-outline-danger" type="submit">Remove</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
          <div class="card-body">
            <h5 class="fw-bold mb-3">Order Summary</h5>
            <div class="d-flex justify-content-between mb-2">
              <span class="text-muted">Total</span>
              <span class="fw-bold">₹<?= number_format($total, 0) ?></span>
            </div>
            <a href="checkout.php" class="btn btn-primary w-100 mt-3">Proceed to Checkout</a>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>

